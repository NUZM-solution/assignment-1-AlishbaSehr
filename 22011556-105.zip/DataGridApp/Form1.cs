﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridApp
{
    public partial class Form1 : Form
    {
        private DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }
        private void createnewrow()
        {
            if (dt.Rows.Count <= 0)
            {
                DataColumn dc1 = new DataColumn("Course Code", typeof(string));
                DataColumn dc2 = new DataColumn("Course Title", typeof(string));
                DataColumn dc3 = new DataColumn("Obtained Marks", typeof(int));
                DataColumn dc4 = new DataColumn("Grade", typeof(String));
                DataColumn dc5 = new DataColumn("Status", typeof(string));

                dt.Columns.Add(dc1);
                dt.Columns.Add(dc2);
                dt.Columns.Add(dc3);
                dt.Columns.Add(dc4);
                dt.Columns.Add(dc5);

                dt.Rows.Add(txtcoursecode.Text, txtName.Text, txtObt.Text, cmb_grade.SelectedItem.ToString(), cmb_status.SelectedItem.ToString());
            }
            else
            {
                dt.Rows.Add(txtcoursecode.Text, txtName.Text, txtObt.Text, cmb_grade.SelectedItem.ToString(), cmb_status.SelectedItem.ToString());
            }

            dataGridView1.DataSource = dt;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_enter_Click(object sender, EventArgs e)
        {
            createnewrow();
        }

        private void btn_print_Click(object sender, EventArgs e)
        {
            // Create a print dialog
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = new PrintDocument();

            // Set the print document's print page event handler
            printDialog.Document.PrintPage += new PrintPageEventHandler(PrintDataGridView);

            // Show the print dialog
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDialog.Document.Print();
            }
        }
        private void PrintDataGridView(object sender, PrintPageEventArgs e)
        {
            // Get the DataGridView's bounds
            Rectangle bounds = dataGridView1.Bounds;

            // Create a bitmap of the DataGridView
            Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height);
            dataGridView1.DrawToBitmap(bitmap, bounds);

            // Draw the bitmap on the print page
            e.Graphics.DrawImage(bitmap, 0, 0);
        }


        private void btn_Exit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void cmb_grade_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
